#! /usr/bin/env python


import rospy
from bodyreader.msg import distance
from bodyreader.msg import car_pid
from qq_msgs.msg import car

advance_new = 0
veer_new = 0
advance = 0
veer = 0

flag = 0

last_speed = [0,0,0,0]
last_integral = 0
last_error = 0
last_all = 0


last_speed_veer = [0,0,0,0]
last_integral_veer = 0
last_error_veer = 0
last_all_veer = 0

laser_motor1 = 0
laser_motor2 = 0
laser_motor3 = 0
laser_motor4 = 0
temp = 0


def follow_speed(dist):
    global advance
    global veer
    advance = dist.z
    # print(advance)
    veer = dist.x

def laser_speed(speed):
    global laser_motor1,laser_motor2,laser_motor3,laser_motor4
    global flag
    laser_motor1 = speed.motor1
    laser_motor2 = speed.motor2
    laser_motor3 = speed.motor3
    laser_motor4 = speed.motor4
    flag = speed.flag

    print("yes")
def pid(input):
    global last_error
    global last_integral
    kp = -0.06
    # kp -0.06
    ki = -0.0001
    # ki    -0.0001
    kd = -0.0005
    #kd -0.0003
    # print(f"input = {input}")
    error = 2000 - input
    integral  = ki*error + last_integral
    if(integral>10):
        integral = 10
    elif(integral<-10):
        integral = -10
    print(integral)
    last_integral = integral
    derivative  = kd*(error-last_error)/0.1
    last_error = error
    all = kp*error + integral + derivative

    return all


def pid_veer(input):
    global last_error_veer
    global last_integral_veer
    kp = 0.015
    # kp -0.06
    ki = 0
    # ki    -0.0001
    kd = 0.0002
    #kd -0.0003
    # print(f"input = {input}")
    error = input
    integral  = ki*error + last_integral_veer
    if(integral>10):
        integral = 10
    elif(integral<-10):
        integral = -10
    print(integral)
    last_integral_veer = integral
    derivative  = kd*(error-last_error_veer)/0.1
    last_error_veer = error
    all = kp*error + integral + derivative
    if(all > 15):
        all = 15
    elif(all < -15):
        all = -15
    return all



if __name__ == "__main__":
    rospy.init_node("car_follow_speed")
    i = 0
    rate = rospy.Rate(10)
    pub = rospy.Publisher("car_follow",car_pid,queue_size=1)
    sub = rospy.Subscriber("get_distance",distance,follow_speed,queue_size=1)
    sub1 = rospy.Subscriber("cml_vel",car,laser_speed,queue_size=1)
    while not rospy.is_shutdown():
        rate.sleep()
        Car_pid = car_pid()
        # print(laser_motor1)
        # print(laser_motor2)
        # print(laser_motor3)
        # print(laser_motor4)
        print(flag)
        if(flag==0):
            if(advance and veer ):
                # print(f"__advance = {advance}")
                advance = pid(advance)
                
                veer = pid_veer(veer)

                print(veer)
                # Car_pid.motor_new[0] = advance + veer + laser_motor1
                # Car_pid.motor_new[1] = advance - veer + laser_motor2
                # Car_pid.motor_new[2] = advance + veer + laser_motor3
                # Car_pid.motor_new[3] = advance - veer + laser_motor4


                # print(f"advance__ = {advance}")
                print("\n")
                last_speed[0] = Car_pid.motor_new[0] = advance + veer + laser_motor1
                last_speed[1] = Car_pid.motor_new[1] = advance - veer + laser_motor2
                last_speed[2] = Car_pid.motor_new[2] = advance + veer + laser_motor3
                last_speed[3] = Car_pid.motor_new[3] = advance - veer + laser_motor4
                pub.publish(Car_pid)
                # i = i+1
                # print(i)
            else:
                Car_pid.motor_new[0] = last_speed[0]
                Car_pid.motor_new[1] = last_speed[1]
                Car_pid.motor_new[2] = last_speed[2]
                Car_pid.motor_new[3] = last_speed[3]
                pub.publish(Car_pid)
        elif flag == 1:
                Car_pid.motor_new[0] = laser_motor1
                Car_pid.motor_new[1] = laser_motor2
                Car_pid.motor_new[2] = laser_motor3
                Car_pid.motor_new[3] = laser_motor4
                print(laser_motor1)
                print(laser_motor2)
                print(laser_motor3)
                print(laser_motor4)
                pub.publish(Car_pid)
                rospy.logwarn("遇到障碍物")