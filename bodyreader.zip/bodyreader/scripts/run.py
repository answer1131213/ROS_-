#! /usr/bin/env python
from bodyreader.msg import car_pid
import rospy
from Rosmaster_Lib import Rosmaster
import subprocess
import copy
import atexit
from qq_msgs.msg import car
set_motor_follow = []

global bot
flag1 = 0

last_speed = 0

def on_exit():
    global bot
    bot.set_motor(0,0,
                  0,0)
    print("程序即将退出，执行清理代码...")

def laser_speed(speed):
    global flag1
    flag1 = speed.flag

def car_callback(follow):
    global set_motor_follow
    set_motor_follow = copy.copy(list(follow.motor_new))

if __name__ == "__main__":
    rospy.init_node("car_node")
    sub = rospy.Subscriber("car_follow",car_pid,car_callback,queue_size=1)
    sub1 = rospy.Subscriber("cml_vel",car,laser_speed,queue_size=1)
    command = ["ls", "-l", "/dev/myserial"]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    stdout, stderr = process.communicate()
    if stdout[-2]=='1':
        com = "/dev/ttyUSB1"
    elif stdout[-2]=='0':
        com = "/dev/ttyUSB0"
    else :
        com = "/dev/myserial"
    bot = Rosmaster(com = com)
    atexit.register(on_exit)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        rate.sleep()  #休眠
        if(set_motor_follow):
            if flag1 == 0:
                for i in range(0,4):
                    if set_motor_follow[i]>40:
                        set_motor_follow[i] = 40
                    elif set_motor_follow[i]<-40:
                        set_motor_follow[i] = -40

                for i in range(0,4):
                    if set_motor_follow[i] == -40:
                        continue
                    else:
                        flag = 1
                        break
                else:
                    if flag == 1:
                        flag = 0
                if flag:
                    rospy.loginfo("%d,%d,%d,%d",set_motor_follow[0],set_motor_follow[1],
                                            set_motor_follow[2],set_motor_follow[3])
                    bot.set_motor(set_motor_follow[0],set_motor_follow[1],
                                set_motor_follow[2],set_motor_follow[3])
            elif flag1 == 1:
                for i in range(0,4):
                    if set_motor_follow[i]>50:
                        set_motor_follow[i] = 50
                    elif set_motor_follow[i]<-50:
                        set_motor_follow[i] = -50
                bot.set_motor(set_motor_follow[0],set_motor_follow[1],
                                set_motor_follow[2],set_motor_follow[3])
                print(set_motor_follow)