#include <astra/capi/astra.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <key_handler.h>
#include <ros/ros.h>
#include <bodyreader/bodyList.h>
#include <bodyreader/distance.h>
#include <vector>

ros::Publisher bodylist_Pub;

float temp_x,temp_z;

void output_bodies(astra_bodyframe_t bodyFrame)
{
    int i;
    astra_body_list_t bodyList;
    bodyreader::bodyList bodylist_msg;
    const astra_status_t rc = astra_bodyframe_body_list(bodyFrame, &bodyList);
    if (rc != ASTRA_STATUS_SUCCESS)
    {
        printf("Error %d in astra_bodyframe_body_list()\n", rc);
        return;
    }
    bodylist_msg.count = bodyList.count;
    for(i = 0; i < bodyList.count; ++i)
    {   

        astra_body_t* body = &bodyList.bodies[i];

        // Pixels in the body mask with the same value as bodyId are
        // from the same body.
        bodylist_msg.bodies[i].bodyid = body->id;
        //printf("+++++++++++++++bodyId = %d\n", bodyId);
        const astra_vector3f_t* centerOfMass = &body->centerOfMass;
        bodylist_msg.bodies[i].centerOfMass.x = centerOfMass->x;
        bodylist_msg.bodies[i].centerOfMass.y = centerOfMass->y;
        bodylist_msg.bodies[i].centerOfMass.z = centerOfMass->z;
        printf("+++++++++++++++++++++centerOfMass->z = %.1f\n", centerOfMass->z);
        printf("+++++++++++++++++++++centerOfMass->y = %.1f\n", centerOfMass->y);
        printf("+++++++++++++++++++++centerOfMass->x = %.1f\n", centerOfMass->x);
        temp_x = centerOfMass->x;
        temp_z = centerOfMass->z;

    }
   
}

void output_bodyframe(astra_bodyframe_t bodyFrame)
{
    output_bodies(bodyFrame);
}

int main(int argc, char* argv[])
{
    ros::init(argc,argv,"get_dist");
    bool body_stream;
    ros::NodeHandle nh;
    ros::NodeHandle node("~"); 
    ros::Publisher pub = nh.advertise<bodyreader::distance>("get_distance",1000);

    bodyreader::distance dist;
    node.param<bool>("body_stream", body_stream, true);
    
    set_key_handler();

    astra_initialize();

    const char* licenseString = "B59st7OH/DdzvkdAonRlyRa+Lygf4zzp23qBqRl1yVjU4aF9Vv5FjfNJ5YQYuaaIxZnJX90AnxJ6a6hO3syHC05hbWU9RmFuWmVmZW5nfE9yZz1aaGVqaWFuZ0h1YXhpbkxpYW5jaHVhbmd8Q29tbWVudD17Y29tbWVudDosY3VzdG9tZXJfdHlwZTppbXBvcnRhbnQsbGljZW5zZV90eXBlOm9mZmxpbmUsdmVyc2lvbjoxfXxFeHBpcmF0aW9uPTE5MjA2OTQwMzY=";
    
    orbbec_body_tracking_set_license(licenseString);

    astra_streamsetconnection_t sensor;

    astra_streamset_open("device/default", &sensor);

    astra_reader_t reader;
    astra_reader_create(sensor, &reader);

    astra_bodystream_t bodyStream;
    astra_reader_get_bodystream(reader, &bodyStream);


    if (body_stream)
    {

        astra_stream_start(bodyStream);
    }
    
    ros::Rate r(10);
    do
    {
        astra_update();

        astra_reader_frame_t frame;
        astra_status_t rc = astra_reader_open_frame(reader, 0, &frame);

        if (rc == ASTRA_STATUS_SUCCESS)
        {
            if (body_stream)
            {
                astra_bodyframe_t bodyFrame;
                astra_frame_get_bodyframe(frame, &bodyFrame);

                astra_frame_index_t frameIndex;
                astra_bodyframe_get_frameindex(bodyFrame, &frameIndex);
                printf("Frame index: %d\n", frameIndex);

                output_bodyframe(bodyFrame);
            }
            printf("----------------------------\n");
            astra_reader_close_frame(&frame);
        }
        dist.x = temp_x;
        dist.z = temp_z;
        pub.publish(dist);
        r.sleep();
        ros::spinOnce();
    } while (shouldContinue);

    astra_reader_destroy(&reader);
    astra_streamset_close(&sensor);

    astra_terminate();

}