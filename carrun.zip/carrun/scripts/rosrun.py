#!/usr/bin/env python3
# coding=utf-8

import rospy
from sensor_msgs.msg import LaserScan
from qq_msgs.msg import car
import time

class PIDController:
    def __init__(self, Kp, Ki, Kd):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.prev_error = 0
        self.integral = 0

    def compute(self, error, dt):
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt
        output = self.Kp * error + self.Ki * self.integral + self.Kd * derivative
        self.prev_error = error
        return output

class ObstacleAvoidance:
    def __init__(self):
        rospy.init_node("obstacle_avoidance_node")
        self.lidar_sub = rospy.Subscriber("/scan", LaserScan, self.lidar_callback)
        self.cmd_pub = rospy.Publisher("cml_vel", car, queue_size=10)
        rospy.loginfo("节点已启动，等待激光雷达数据")
        rospy.on_shutdown(self.shutdown_hook)
        self.rate = rospy.Rate(10)  # 10Hz

        self.safe_distance = 0.6 # 安全距离
        self.target_distance = 1.2
          # 目标距离（保持的距离）
        self.speed = 45 # 速度
        self.speed4_3 = self.speed +5   # 左移速度调整

        self.pid_controller = PIDController(Kp=0.5, Ki=0.0, Kd=0.0)
        self.last_time = time.time()

    def lidar_callback(self, msg):
        center_index_start = int(len(msg.ranges) / 2 - 5)
        center_index_end = int(len(msg.ranges) / 2 + 5)
        center_ranges = msg.ranges[center_index_start:center_index_end]
        min_center_range = min(center_ranges)

        left_ranges = msg.ranges[:len(msg.ranges)//4]
        right_ranges = msg.ranges[3*len(msg.ranges)//4:]
        min_right_range = min(left_ranges)
        min_left_range = min(right_ranges)

         # 检测后方是否有障碍物
        behind_index_start = int(len(msg.ranges) - len(msg.ranges)//4)
        behind_index_end = int(len(msg.ranges) - len(msg.ranges)//8)
        behind_ranges = msg.ranges[behind_index_start:behind_index_end]
        min_behind_range = min(behind_ranges)

        error = self.target_distance - min_center_range
        current_time = time.time()
        dt = current_time - self.last_time
        self.last_time = current_time

        control_signal = self.pid_controller.compute(error, dt)

        cmd = car()
        if min_center_range < self.safe_distance and min_left_range < self.safe_distance and min_right_range < self.safe_distance:
            cmd.motor1 = cmd.motor2 = cmd.motor3 = cmd.motor4 = -self.speed
            rospy.logwarn("前左右有障碍物，向后退,速度为%d,%d,%d,%d", cmd.motor1, cmd.motor2, cmd.motor3, cmd.motor4)
            cmd.flag = 1
            rospy.sleep(0.2)
        elif min_center_range < self.safe_distance and min_right_range < self.safe_distance:
            cmd.motor1 = -self.speed
            cmd.motor4 = -self.speed4_3
            cmd.motor2 = self.speed
            cmd.motor3 = self.speed4_3
            rospy.logwarn("前右有障碍物,距离为%2f，左移,速度为%d,%d,%d,%d", min_center_range, cmd.motor1, cmd.motor2, cmd.motor3, cmd.motor4)
            cmd.flag =1
            rospy.sleep(0.2)
        elif min_center_range < self.safe_distance:
            cmd.motor1 = -self.speed
            cmd.motor4 = -self.speed4_3
            cmd.motor2 = self.speed
            cmd.motor3 = self.speed4_3
            rospy.logwarn("前右有障碍物,距离为%2f，左移,速度为%d,%d,%d,%d", min_center_range, cmd.motor1, cmd.motor2, cmd.motor3, cmd.motor4)
            cmd.flag =1
            rospy.sleep(0.2)
        elif min_center_range < self.safe_distance or min_left_range < self.safe_distance:
            cmd.motor1 = self.speed
            cmd.motor4 = self.speed4_3
            cmd.motor2 = -self.speed
            cmd.motor3 = -self.speed4_3
            rospy.logwarn("前左有障碍物,距离为%2f，右移,速度为%d,%d,%d,%d", min_center_range, cmd.motor1, cmd.motor2, cmd.motor3, cmd.motor4)
            rospy.sleep(0.2)
            cmd.flag = 1
        elif min_behind_range < self.safe_distance:
            cmd.motor1 = self.speed
            cmd.motor4 = self.speed4_3
            cmd.motor2 = -self.speed
            cmd.motor3 = -self.speed4_3
            rospy.logwarn("后有障碍物,距离为%2f，右移,速度为%d,%d,%d,%d", min_center_range, cmd.motor1, cmd.motor2, cmd.motor3, cmd.motor4)
            rospy.sleep(0.2)
            cmd.flag = 1
        else:
            cmd.flag=0

        # cmd.motor1 += control_signal
        # cmd.motor2 += control_signal
        # cmd.motor3 -= control_signal
        # cmd.motor4 -= control_signal
        self.cmd_pub.publish(cmd)

    def shutdown_hook(self):
        cmd = car()
        cmd.motor1 = cmd.motor2 = cmd.motor3 = cmd.motor4 = 0
        self.cmd_pub.publish(cmd)
        rospy.loginfo("节点关闭，发送速度为0的命令")

    def run(self):
        while not rospy.is_shutdown():
            self.rate.sleep()


if __name__ == "__main__":
    node = ObstacleAvoidance() #创建类时，已经调用了init
    node.run()

